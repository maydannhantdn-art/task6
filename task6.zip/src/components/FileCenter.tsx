/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User } from '../types';
import { 
  FileBox, 
  FileText, 
  Download, 
  ExternalLink, 
  PlusSquare, 
  Search, 
  HardDrive, 
  Info, 
  Copy, 
  Check, 
  X, 
  BookOpen, 
  ArrowRight 
} from 'lucide-react';
import { USER_MANUAL_SECTIONS, RAW_MARKDOWN_MANUAL } from '../data/userManualData';

interface FileCenterProps {
  currentUser: User;
}

export default function FileCenter({ currentUser }: FileCenterProps) {
  const [search, setSearch] = useState('');
  const [uploadMsg, setUploadMsg] = useState('');
  const [showManualModal, setShowManualModal] = useState(false);
  const [copiedManual, setCopiedManual] = useState(false);
  const [activeManualSection, setActiveManualSection] = useState(USER_MANUAL_SECTIONS[0].id);

  const [docs, setDocs] = useState([
    { 
      id: 'manual_doc', 
      title: 'Tài liệu Hướng dẫn Sử dụng Tín Dân CRM v1.0', 
      type: 'MARKDOWN (.md)', 
      size: '12 KB', 
      folder: 'Admin', 
      date: '2026-06-09', 
      author: 'Vivian System AI',
      isManual: true 
    },
    { id: '1', title: 'Quy chuẩn Máy Sấy Khô UV Vivian v2.1', type: 'PDF', size: '2.4 MB', folder: 'Kỹ thuật', date: '2026-05-12', author: 'Trần Minh Đức' },
    { id: '2', title: 'Thiết Kế Decal Nhãn Cuộn 3 Lớp VF5 Red', type: 'AI (Illustrator)', size: '14.8 MB', folder: 'Marketing', date: '2026-06-01', author: 'Nguyễn Văn Nam' },
    { id: '3', title: 'Biên Bản Họp Giao Việc Đầu Tháng 6 - GĐ Tuấn Anh', type: 'Word (.docx)', size: '420 KB', folder: 'Admin', date: '2026-06-02', author: 'Trần Tuấn Anh' },
    { id: '4', title: 'Bảng Báo Giá Phôi Nhãn Decal Chống Giả', type: 'Excel (.xlsx)', size: '1.2 MB', folder: 'Sale', date: '2026-05-28', author: 'Lê Thị Thuỷ' }
  ]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      const newDoc = {
        id: 'doc_' + Date.now(),
        title: file.name.split('.')[0],
        type: file.name.split('.').pop()?.toUpperCase() || 'FILE',
        size: `${Math.round(file.size / 1024)} KB`,
        folder: currentUser.department,
        date: new Date().toISOString().split('T')[0],
        author: currentUser.name,
        isManual: false
      };

      setDocs([newDoc, ...docs]);
      setUploadMsg(`Đã tải lên và lưu vào đám mây tài liệu "${file.name}"!`);
      setTimeout(() => setUploadMsg(''), 4000);
    }
  };

  const downloadManualFile = () => {
    try {
      const blob = new Blob([RAW_MARKDOWN_MANUAL], { type: 'text/markdown;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'HUONG_DAN_SU_DUNG_TIN_DAN_CRM.md');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      setUploadMsg('Đã tải tài liệu "HUONG_DAN_SU_DUNG_TIN_DAN_CRM.md" về máy trạm thành công!');
      setTimeout(() => setUploadMsg(''), 4000);
    } catch (err: any) {
      alert('Lỗi tải tệp: ' + err.message);
    }
  };

  const handleDownload = (doc: any, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent opening modal on download icon click
    if (doc.isManual) {
      downloadManualFile();
    } else {
      setUploadMsg(`Đang tải tệp "${doc.title}.${doc.type.toLowerCase()}" về máy trạm...`);
      setTimeout(() => setUploadMsg(''), 4000);
    }
  };

  const handleCopyManual = () => {
    try {
      navigator.clipboard.writeText(RAW_MARKDOWN_MANUAL);
      setCopiedManual(true);
      setTimeout(() => setCopiedManual(false), 3000);
    } catch (err) {
      // Fallback
      alert('Đã chọn toàn bộ! Nhấn Ctrl+C để copy.');
    }
  };

  const filteredDocs = docs.filter(d => d.title.toLowerCase().includes(search.toLowerCase()) || d.folder.toLowerCase().includes(search.toLowerCase()));
  const currentSectionDetails = USER_MANUAL_SECTIONS.find(s => s.id === activeManualSection) || USER_MANUAL_SECTIONS[0];

  return (
    <div className="space-y-6 max-w-7xl mx-auto p-4 md:p-6 lg:p-8 font-sans">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white font-display flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-blue-600" />
            <span>Tài Liệu Xưởng & Thư Viện Đám Mây</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Kho lưu trữ quy chuẩn thiết kế màng decal, vận hành máy sây UV, và cổng sách hướng dẫn CRM.</p>
        </div>

        {/* Action column links */}
        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          {/* Quick open manual */}
          <button
            onClick={() => setShowManualModal(true)}
            className="flex-1 sm:flex-none py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
          >
            <BookOpen className="w-4 h-4" />
            <span>Xem nhanh Sách HDSD CRM</span>
          </button>

          {/* Upload file */}
          <div className="relative flex-1 sm:flex-none w-auto">
            <label className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all">
              <PlusSquare className="w-4 h-4" />
              <span>Tải Lên File</span>
              <input
                type="file"
                onChange={handleFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer w-0 h-0"
              />
            </label>
          </div>
        </div>
      </div>

      {uploadMsg && (
        <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/15 text-emerald-600 dark:text-emerald-400 text-xs rounded-xl flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span>{uploadMsg}</span>
        </div>
      )}

      {/* Grid columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left hand: directories list */}
        <div className="lg:col-span-8 space-y-4">
          <div className="glass-card rounded-2xl p-5 space-y-4">
            
            {/* Search filter docs */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Tìm tên tài liệu, đuôi định dạng, thư mục phòng ban..."
                className="w-full glass-input rounded-lg text-xs py-2 pl-9 pr-4 focus:outline-none"
              />
            </div>

            {/* Document listings stack table */}
            <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
              {filteredDocs.length === 0 ? (
                <p className="p-8 text-center text-slate-400 text-xs italic">Không tìm thấy tài liệu phù hợp.</p>
              ) : (
                filteredDocs.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => doc.isManual ? setShowManualModal(true) : null}
                    className={`p-3.5 border rounded-xl flex items-center justify-between gap-4 text-xs transition-all ${
                      doc.isManual 
                        ? 'border-emerald-500/30 bg-emerald-500/5 hover:border-emerald-500 dark:bg-emerald-500/10 cursor-pointer' 
                        : 'border-white/5 bg-white/5 dark:bg-black/20 hover:border-blue-500 cursor-default'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2.5 rounded-lg ${doc.isManual ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600' : 'bg-blue-50 dark:bg-blue-900/20 text-blue-600'}`}>
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-semibold text-slate-900 dark:text-white font-display block">{doc.title}</span>
                          {doc.isManual && (
                            <span className="px-1.5 py-0.5 rounded-full bg-emerald-500 text-white font-semibold text-[8px] tracking-wider uppercase">HƯỚNG DẪN MỚI</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 font-mono">
                          <span className="bg-slate-200 dark:bg-slate-800 px-1 rounded text-slate-500 font-bold uppercase">{doc.type}</span>
                          <span>{doc.size}</span>
                          <span>•</span>
                          <span>Phòng: <b>{doc.folder}</b></span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-400 hidden sm:inline">Tác giả: <b>{doc.author}</b></span>
                      <button
                        onClick={(e) => handleDownload(doc, e)}
                        className={`p-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                          doc.isManual 
                            ? 'bg-emerald-100 hover:bg-emerald-600 hover:text-white text-emerald-700 dark:bg-emerald-900/20' 
                            : 'bg-slate-100 hover:bg-blue-600 hover:text-white dark:bg-slate-800 text-slate-500'
                        }`}
                        title="Tải tệp này"
                      >
                        <Download className="w-3.5 h-3.5" />
                        {doc.isManual && <span className="text-[10px] pr-0.5 hidden md:inline font-semibold">Tải ngay</span>}
                      </button>
                    </div>

                  </div>
                ))
              )}
            </div>

          </div>
        </div>

        {/* Right hand: Specifications and instructions warning */}
        <div className="lg:col-span-4 space-y-4">
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold font-display text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-blue-500" />
              <span>Dung Lượng Lưu Trữ</span>
            </h3>

            <div className="space-y-2">
              <div className="h-2 bg-slate-100 dark:bg-slate-850 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full w-[45%]" />
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Đã dùng: 21.6 MB / 50 MB</span>
                <span>43.2%</span>
              </div>
            </div>

            <div className="p-3.5 bg-emerald-500/5 dark:bg-emerald-500/10 border border-emerald-500/10 rounded-xl space-y-2 text-xs leading-relaxed">
              <div className="flex items-center gap-1.5 font-bold font-display text-[11px] uppercase text-emerald-600">
                <BookOpen className="w-4 h-4 shrink-0" />
                <span>Bạn muốn đào tạo nhân viên?</span>
              </div>
              <p className="text-slate-600 dark:text-slate-350">
                Hãy click xem cuốn <b>Sách HDSD CRM</b> để phổ biến quyền hạn và các bước vận hành thông minh cho CSKH, Admin, và Kỹ thuật xưởng! Có đủ nút Copy và Tải Tài Liệu về làm cẩm nang gối đầu giường.
              </p>
            </div>

            <div className="p-3.5 bg-white/5 dark:bg-black/10 border border-white/5 rounded-xl space-y-2 text-xs font-light text-slate-600 dark:text-slate-350 leading-relaxed">
              <div className="flex items-center gap-1.5 font-bold font-display text-[11px] uppercase text-blue-600">
                <Info className="w-4 h-4 shrink-0" />
                <span>Quy chuẩn tệp Tem Vivian</span>
              </div>
              <p>Mọi bản in Decal màng Vivian phải xuất file đúng định dạng vector hệ màu CMYK và tích hợp lớp phủ UV tự động rải sấy trước khi chuyển lệnh xuống máy xưởng.</p>
            </div>

          </div>
        </div>

      </div>

      {/* DETAILED INTERACTIVE INTERPRETER MANUAL MODAL */}
      {showManualModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-5xl w-full max-h-[90vh] flex flex-col shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-100 dark:border-slate-800/80 flex justify-between items-center bg-slate-50 dark:bg-slate-950/40 rounded-t-3xl">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500/10 text-emerald-600 rounded-lg">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base md:text-lg font-bold font-display text-slate-900 dark:text-white">Cẩm Nang Vận Hành & Đào Tạo Tín Dân CRM</h2>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">Vivian System v1.0 • Cập nhật ngày 09/06/2026</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyManual}
                  className={`flex items-center gap-1 px-3 py-1.5 border justify-center rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    copiedManual 
                      ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600' 
                      : 'border-slate-200 dark:border-slate-800 bg-white hover:bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-350'
                  }`}
                  title="Sao chép toàn bộ văn bản để gửi qua Zalo/Word"
                >
                  {copiedManual ? <Check className="w-3.5 h-3.5 animate-pulse" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedManual ? 'Đã copy!' : 'Copy tài liệu'}</span>
                </button>

                <button
                  onClick={downloadManualFile}
                  className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-all cursor-pointer active:scale-95"
                  title="Tải tệp .md về xem offline"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tải .md về máy</span>
                </button>

                <button
                  onClick={() => setShowManualModal(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Workspace Body Content */}
            <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
              
              {/* Sidebar Tabs for module folders */}
              <div className="w-full md:w-56 border-r border-slate-100 dark:border-slate-800/80 overflow-y-auto p-4 space-y-1 bg-slate-50/50 dark:bg-slate-950/20">
                <span className="text-[10px] font-bold text-slate-400 dark:text-slate-650 tracking-wider uppercase block pb-2 px-2 border-b border-slate-100 dark:border-slate-850 mb-2">DANH MỤC HƯỚNG DẪN</span>
                {USER_MANUAL_SECTIONS.map((sec) => (
                  <button
                    key={sec.id}
                    onClick={() => setActiveManualSection(sec.id)}
                    className={`w-full text-left px-3 py-2 text-xs font-medium rounded-lg transition-all flex items-center gap-2 ${
                      activeManualSection === sec.id
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-450 border border-emerald-500/15 font-semibold'
                        : 'text-slate-600 dark:text-slate-450 hover:bg-slate-100 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <span className="text-[10.5px] font-normal font-mono text-emerald-500">▶</span>
                    <span>{sec.name}</span>
                  </button>
                ))}
              </div>

              {/* Main Reading area */}
              <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
                
                {/* Sector objective title */}
                <div className="border-b border-slate-100 dark:border-slate-850 pb-4">
                  <h3 className="text-base md:text-lg font-bold font-display text-slate-999 dark:text-white text-left tracking-tight">
                    {currentSectionDetails.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 text-left mt-1.5 leading-relaxed font-light">
                    <b>Mục tiêu Module:</b> {currentSectionDetails.objective}
                  </p>
                </div>

                {/* Sub-roles separation boxes */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  
                  {/* Sếp card style */}
                  <div className="p-4 bg-amber-500/5 border border-amber-500/15 rounded-2xl space-y-1">
                    <span className="text-[9px] font-bold font-mono text-amber-600 dark:text-amber-500 uppercase tracking-widest block">👑 Sếp Tuấn Anh</span>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-light leading-relaxed text-left">
                      {currentSectionDetails.forSếp}
                    </p>
                  </div>

                  {/* Admin card */}
                  <div className="p-4 bg-sky-500/5 border border-sky-500/15 rounded-2xl space-y-1">
                    <span className="text-[9px] font-bold font-mono text-sky-600 dark:text-sky-400 uppercase tracking-widest block">👔 CDV / Quản trị viên</span>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-light leading-relaxed text-left">
                      {currentSectionDetails.forAdmin}
                    </p>
                  </div>

                  {/* Employees card info */}
                  <div className="p-4 bg-emerald-500/5 border border-emerald-500/15 rounded-2xl space-y-1">
                    <span className="text-[9px] font-bold font-mono text-emerald-600 dark:text-emerald-450 uppercase tracking-widest block">👩‍💼 CSKH / Nhân viên</span>
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-light leading-relaxed text-left">
                      {currentSectionDetails.forCS}
                    </p>
                  </div>

                </div>

                {/* Walkthrough list */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold font-display uppercase tracking-widest text-slate-800 dark:text-white flex items-center gap-1.5">
                    <ArrowRight className="w-3.5 h-3.5 text-blue-500" />
                    <span>Các bước thao tác chi tiết:</span>
                  </h4>

                  <ul className="space-y-2 mt-2">
                    {currentSectionDetails.howToUse.map((step, idx) => (
                      <li key={idx} className="flex gap-2.5 text-xs text-slate-600 dark:text-slate-350 text-left items-start leading-relaxed bg-slate-50 dark:bg-black/10 p-3 rounded-xl">
                        <span className="font-mono bg-blue-500/15 px-1.5 py-0.5 rounded text-blue-600 dark:text-blue-400 font-bold text-[10.5px] shrink-0">{idx + 1}</span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Integration Info Box */}
                <div className="p-4 bg-blue-500/5 border border-blue-500/10 rounded-2xl text-[11px] text-slate-500 leading-relaxed text-left">
                  💡 <b>Mẹo quản trị màng rải sấy UV:</b> Đóng các tab hoặc nội dung không liên quan để bảo toàn lưu lượng, hệ thống sẽ tự động dừng tải các module thụ động. Nếu nghi ngờ dữ liệu chưa khớp, hãy click vào nút <b>"Đồng bộ CRM"</b> trên thanh tiêu đề của trang để cập nhật live mượt mà tức khắc!
                </div>

              </div>

            </div>

            {/* Footer containing quick link disclaimer */}
            <div className="p-4 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50 dark:bg-slate-950/60 rounded-b-3xl text-center text-[10px] text-slate-400 flex flex-col md:flex-row justify-between items-center px-6 gap-2">
              <span>Được biên soạn tự động từ máy chủ Vivian AI • Vivian Labeling Solutions</span>
              <span>Website: <a href="https://temvivian.vn" target="_blank" rel="noopener noreferrer" className="text-emerald-600 dark:text-emerald-400 font-semibold hover:underline inline-flex items-center gap-0.5">temvivian.vn <ExternalLink className="w-2.5 h-2.5" /></a></span>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
