import { db } from './firebase';
import { collection, doc, getDocs, setDoc, deleteDoc, query, limit, onSnapshot } from 'firebase/firestore';
import { Task, Project, KPIs, User, EmployeeWorkload, TaskRiskScore, ZaloOAConfig, ZaloWebhookMessage, Lead, Notification } from '../types';

// Helper to manage localStorage cache
const getLocalCache = <T>(key: string, fallback: T): T => {
  try {
    const data = localStorage.getItem(`tindan_${key}`);
    return data ? JSON.parse(data) : fallback;
  } catch {
    return fallback;
  }
};

const setLocalCache = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(`tindan_${key}`, JSON.stringify(value));
  } catch {
    // Ignore
  }
};

// Rich, realistic initial mock data for Tín Dân Company
const initialUsers: User[] = [
  { 
    id: '1', 
    name: 'Admin', 
    email: 'admin@tindan.com', 
    role: 'CEO / Quản lý tối cao', 
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
    password: '123456',
    permissions: ['workspace', 'inbox', 'tasks', 'projects', 'teams', 'crm', 'ai-command', 'knowledge', 'kpis', 'automation', 'notifications', 'files', 'settings']
  },
  { 
    id: '2', 
    name: 'Nguyễn Văn Đạt', 
    email: 'dat.nguyen@tindan.com', 
    role: 'Trưởng phòng Phát triển', 
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    password: '123',
    permissions: ['workspace', 'tasks', 'projects', 'knowledge', 'notifications', 'files']
  },
  { 
    id: '3', 
    name: 'Lê Thị Mỹ Duyên (AI Chatbot)', 
    email: 'duyen.ai@tindan.com', 
    role: 'Đại diện Chatbot', 
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    password: '123',
    permissions: ['workspace', 'inbox', 'crm', 'knowledge']
  },
  { 
    id: '4', 
    name: 'Phạm Hồng Nam', 
    email: 'nam.pham@tindan.com', 
    role: 'Chuyên viên Tối ưu CRO', 
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
    password: '123',
    permissions: ['workspace', 'tasks', 'knowledge', 'kpis', 'notifications', 'files']
  }
];

const initialProjects: Project[] = [];
const initialTasks: Task[] = [];
const initialKPIs: KPIs[] = [];
const initialWorkloads: EmployeeWorkload[] = [];
const initialRisks: TaskRiskScore[] = [];
const initialLeads: Lead[] = [];
const initialNotifications: Notification[] = [];
const initialZaloOAs: ZaloOAConfig[] = [];

const withTimeout = <T>(promise: Promise<T>, timeoutMs: number = 8000): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => 
      setTimeout(() => reject(new Error('Connection timeout')), timeoutMs)
    )
  ]);
};

export const dataStore = {
  // Generic Read Operation từ Firestore Cloud (Online-First)
  getDocuments: async <T>(collectionId: string, defaultData: T[]): Promise<T[]> => {
    try {
      const colRef = collection(db, collectionId);
      const snapshot = await getDocs(colRef);
      const cloudList: T[] = [];
      snapshot.forEach((doc) => {
        cloudList.push({ id: doc.id, ...doc.data() } as unknown as T);
      });
      
      if (cloudList.length > 0) {
        console.log(`[Tín Dân OS] Đã đồng bộ thành công ${cloudList.length} bản ghi cho danh mục "${collectionId}" từ Cloud Firestore.`);
        setLocalCache(collectionId, cloudList);
        return cloudList;
      } else {
        // Nếu trên Cloud hoàn toàn rỗng, kiểm tra Local Cache để tránh ghi đè trắng
        const cached = getLocalCache<T[]>(collectionId, []);
        if (cached && cached.length > 0) {
          console.log(`[Tín Dân OS] Cloud "${collectionId}" rỗng, nạp thành công từ bộ nhớ đệm (Local Cache) an toàn.`);
          return cached;
        }
        // Fallback nạp dữ liệu ban đầu
        console.log(`[Tín Dân OS] Khởi tạo dữ liệu mặc định cho "${collectionId}".`);
        setLocalCache(collectionId, defaultData);
        return defaultData;
      }
    } catch (err) {
      console.warn(`[dataStore] Firestore fetch failed for collection "${collectionId}":`, err);
      // Fallback thầm lặng về Cache nếu thật sự rớt mạng
      return getLocalCache<T[]>(collectionId, defaultData);
    }
  },

  // Generic Save / Update Operation lên Firestore Cloud
  saveDocument: async <T extends { id: string }>(collectionId: string, docId: string, item: any, defaultData: T[]): Promise<any> => {
    const cleanItem = { ...item };
    
    // Clean các trường Appwrite $ cũ nếu có dính líu
    Object.keys(cleanItem).forEach(k => {
      if (k.startsWith('$') || k === 'id') {
        if (k.startsWith('$')) {
          delete cleanItem[k];
        }
      }
    });

    // 1. Đồng bộ lên Firestore Cloud lập tức
    try {
      const docRef = doc(db, collectionId, docId);
      await setDoc(docRef, cleanItem, { merge: true });
      console.log(`[dataStore] Cloud Firestore synced: ${collectionId}/${docId}`);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('firestore-sync-status', {
          detail: { success: true, collectionId, docId, action: 'save', name: cleanItem.name || null }
        }));
      }
    } catch (err: any) {
      console.error(`[dataStore] Cloud Firestore sync failed for ${collectionId}/${docId}:`, err);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('firestore-sync-status', {
          detail: { success: false, error: err.message || String(err), collectionId, docId, action: 'save', name: cleanItem.name || null }
        }));
      }
    }

    // 2. Cập nhật cache Local để đảm bảo offline-resilience
    const list = getLocalCache<T[]>(collectionId, defaultData);
    const index = list.findIndex(x => x.id === docId);
    if (index >= 0) {
      list[index] = { ...list[index], ...cleanItem };
    } else {
      list.unshift({ id: docId, ...cleanItem });
    }
    setLocalCache(collectionId, list);

    return cleanItem;
  },

  // Generic Delete Operation từ Firestore Cloud
  deleteDocument: async <T extends { id: string }>(collectionId: string, docId: string, defaultData: T[]): Promise<boolean> => {
    // 1. Xóa trên Firestore Cloud
    try {
      const docRef = doc(db, collectionId, docId);
      await deleteDoc(docRef);
      console.log(`[dataStore] Cloud Firestore deleted: ${collectionId}/${docId}`);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('firestore-sync-status', {
          detail: { success: true, collectionId, docId, action: 'delete' }
        }));
      }
    } catch (err: any) {
      console.error(`[dataStore] Cloud Firestore delete failed for ${collectionId}/${docId}:`, err);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('firestore-sync-status', {
          detail: { success: false, error: err.message || String(err), collectionId, docId, action: 'delete' }
        }));
      }
    }

    // 2. Xóa ở cache local
    const list = getLocalCache<T[]>(collectionId, defaultData);
    const updated = list.filter(x => x.id !== docId);
    setLocalCache(collectionId, updated);
    return true;
  },

  // Realtime subscribe, kéo mượt trực tiếp từ Firestore qua onSnapshot WebChannel
  subscribeToCollection: (collectionId: string, onUpdate: (data: any[]) => void, defaultData: any[]): (() => void) => {
    try {
      const colRef = collection(db, collectionId);
      const unsubscribe = onSnapshot(colRef, (snapshot) => {
        const cloudList: any[] = [];
        snapshot.forEach((doc) => {
          cloudList.push({ id: doc.id, ...doc.data() });
        });
        
        if (cloudList.length > 0) {
          console.log(`[Tín Dân OS Cloud Realtime] Đồng bộ hóa mượt mà kênh: "${collectionId}" (${cloudList.length} tài liệu).`);
          setLocalCache(collectionId, cloudList);
          onUpdate(cloudList);
        } else {
          // Cloud rỗng, nạp từ cache tránh xóa trắng cục bộ bộ cài đặt của Sếp
          const cached = getLocalCache<any[]>(collectionId, []);
          if (cached && cached.length > 0) {
            console.log(`[Tín Dân OS Cloud Realtime] Kênh "${collectionId}" trên Cloud rỗng, duy trì an toàn ${cached.length} bản ghi từ Local Cache.`);
            onUpdate(cached);
          } else {
            console.log(`[Tín Dân OS Cloud Realtime] Kênh "${collectionId}" rỗng, khởi tạo mặc định.`);
            setLocalCache(collectionId, defaultData);
            onUpdate(defaultData);
          }
        }
      }, (err) => {
        console.warn(`[dataStore] Sụp lỗi subcription cho ${collectionId}, tải cache local:`, err);
        onUpdate(getLocalCache(collectionId, defaultData));
      });
      return unsubscribe;
    } catch (err) {
      console.error(`[dataStore] Đăng ký subcription thất bại cho ${collectionId}:`, err);
      onUpdate(getLocalCache(collectionId, defaultData));
      return () => {};
    }
  },

  // 1. TAM QUẢN: NHIỆM VỤ, DỰ ÁN, KPIS
  getTasks: async (): Promise<Task[]> => dataStore.getDocuments<Task>('tasks', initialTasks),
  saveTask: async (task: Task): Promise<Task> => dataStore.saveDocument<Task>('tasks', task.id, task, initialTasks),
  deleteTask: async (id: string): Promise<boolean> => dataStore.deleteDocument<Task>('tasks', id, initialTasks),

  getProjects: async (): Promise<Project[]> => dataStore.getDocuments<Project>('projects', initialProjects),
  saveProject: async (proj: Project): Promise<Project> => dataStore.saveDocument<Project>('projects', proj.id, proj, initialProjects),
  deleteProject: async (id: string): Promise<boolean> => dataStore.deleteDocument<Project>('projects', id, initialProjects),

  getKPIs: async (): Promise<KPIs[]> => dataStore.getDocuments<KPIs>('kpis', initialKPIs),
  saveKPI: async (kpi: KPIs): Promise<KPIs> => dataStore.saveDocument<KPIs>('kpis', kpi.id, kpi, initialKPIs),
  deleteKPI: async (id: string): Promise<boolean> => dataStore.deleteDocument<KPIs>('kpis', id, initialKPIs),

  getUsers: async (): Promise<User[]> => dataStore.getDocuments<User>('users', initialUsers),

  // Workloads & Risks
  getWorkloads: async (): Promise<EmployeeWorkload[]> => dataStore.getDocuments<EmployeeWorkload>('employee_workload', initialWorkloads),
  getRiskScores: async (): Promise<TaskRiskScore[]> => dataStore.getDocuments<TaskRiskScore>('task_risk', initialRisks),

  // 2. LEAD VỒN, WEBHOOKS, ZALO OA
  getLeads: async (): Promise<Lead[]> => dataStore.getDocuments<Lead>('chatbot_duyen_leads', initialLeads),
  saveLead: async (lead: Lead): Promise<Lead> => dataStore.saveDocument<Lead>('chatbot_duyen_leads', lead.id, lead, initialLeads),

  getZaloOAs: async (): Promise<ZaloOAConfig[]> => dataStore.getDocuments<ZaloOAConfig>('zalo_oa_configurations', initialZaloOAs),
  saveZaloOA: async (oa: ZaloOAConfig): Promise<ZaloOAConfig> => dataStore.saveDocument<ZaloOAConfig>('zalo_oa_configurations', oa.id, oa, initialZaloOAs),
  deleteZaloOA: async (id: string): Promise<boolean> => dataStore.deleteDocument<ZaloOAConfig>('zalo_oa_configurations', id, initialZaloOAs),

  getZaloMessages: async (): Promise<ZaloWebhookMessage[]> => {
    try {
      const res = await fetch('/api/zalo/messages');
      const data = await res.json();
      if (data.success) {
        setLocalCache('zalo_webhook_messages', data.list);
        return data.list;
      }
    } catch {}
    return getLocalCache<ZaloWebhookMessage[]>('zalo_webhook_messages', []);
  },

  getNotifications: async (): Promise<Notification[]> => dataStore.getDocuments<Notification>('notifications', initialNotifications),
  saveNotification: async (notif: Notification): Promise<Notification> => dataStore.saveDocument<Notification>('notifications', notif.id, notif, initialNotifications),

  // 3. CHAT HISTORY STORE
  getChatHistory: async (userId: string): Promise<any[]> => {
    const key = `chat_history_${userId}`;
    const local = getLocalCache<any[]>(key, []);
    try {
      const q = collection(db, 'chat_history');
      const querySnapshot = await withTimeout(getDocs(query(q, limit(100))), 3000);
      const list: any[] = [];
      querySnapshot.forEach((doc) => {
        const item = doc.data();
        if (item.userId === userId) {
          list.push({ id: doc.id, ...item });
        }
      });
      list.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      if (list.length > 0) {
        setLocalCache(key, list);
        return list;
      }
    } catch (e) {
      console.warn('[dataStore] Lịch sử chat Firebase không khả dụng:', e);
    }
    local.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    return local;
  },

  saveChatMessage: async (userId: string, sender: 'user' | 'assistant', text: string): Promise<any> => {
    const msgObj = {
      id: Math.random().toString(36).substring(7),
      userId,
      sender,
      text,
      timestamp: new Date().toISOString()
    };
    const key = `chat_history_${userId}`;
    const local = getLocalCache<any[]>(key, []);
    local.push(msgObj);
    setLocalCache(key, local);

    try {
      const docRef = doc(collection(db, 'chat_history'), msgObj.id);
      await withTimeout(setDoc(docRef, msgObj), 3000);
    } catch (e) {
      console.error('[dataStore] Ghi tin nhắn Firebase thất bại:', e);
    }
    return msgObj;
  },

  // Diagnostics check connection
  testFirestoreConnection: async (): Promise<{ success: boolean; message: string; latencyMs?: number }> => {
    const startTime = Date.now();
    try {
      // Đọc 1 document từ collection bất kỳ của Firebase Firestore
      const q = collection(db, 'tasks');
      await withTimeout(getDocs(query(q, limit(1))), 3000);
      const latency = Date.now() - startTime;
      return {
        success: true,
        message: 'Đã kết nối Firebase Firestore tối tân. Toàn bộ cơ sở dữ liệu CRM Tín Dân sẵn sàng.',
        latencyMs: latency
      };
    } catch (e: any) {
      return {
        success: false,
        message: `Lỗi kết nối Firebase Firestore Cloud: ${e.message || String(e)}`
      };
    }
  }
};

// Complete DB wrapper for modular components
export const DB = {
  ...dataStore,

  // User methods
  saveUser: async (user: User): Promise<User> => {
    return dataStore.saveDocument<User>('users', user.id, user, initialUsers);
  },
  updateUser: async (userId: string, fields: Partial<User>): Promise<User> => {
    const users = await dataStore.getUsers();
    const user = users.find(u => u.id === userId);
    const updated = { ...user, ...fields, id: userId } as User;
    return dataStore.saveDocument<User>('users', userId, updated, initialUsers);
  },
  deleteUser: async (userId: string): Promise<boolean> => {
    return dataStore.deleteDocument<User>('users', userId, initialUsers);
  },
  subscribeToUsers: (onUpdate: (users: User[]) => void): (() => void) => {
    return dataStore.subscribeToCollection('users', onUpdate, initialUsers);
  },
  getCachedUsers: (): User[] => {
    return getLocalCache<User[]>('users', initialUsers);
  },
  getCurrentUser: (): User | null => {
    return getLocalCache<User | null>('current_user', initialUsers[0]);
  },
  setCurrentUser: (user: User | null): void => {
    setLocalCache('current_user', user);
  },
  clearSystemCache: (): void => {
    try {
      const keys = Object.keys(localStorage);
      keys.forEach(k => {
        if (k.startsWith('tindan_')) {
          localStorage.removeItem(k);
        }
      });
      window.location.reload();
    } catch {}
  },

  // Project methods
  saveProjects: async (projects: Project[]): Promise<void> => {
    setLocalCache('projects', projects);
    for (const proj of projects) {
      await dataStore.saveProject(proj);
    }
  },

  // Task methods
  saveTasks: async (tasks: Task[]): Promise<void> => {
    setLocalCache('tasks', tasks);
    for (const task of tasks) {
      await dataStore.saveTask(task);
    }
  },

  // Activity logs
  getActivityLogs: async (): Promise<any[]> => {
    return getLocalCache<any[]>('activity_logs', [
      { id: 'log_init', action: 'Hệ thống khởi chạy thành công', performedBy: 'Hệ thống', timestamp: new Date().toISOString() }
    ]);
  },
  saveActivityLogs: async (logs: any[]): Promise<void> => {
    setLocalCache('activity_logs', logs);
  },
  saveActivityLog: async (log: any): Promise<void> => {
    const logs = await DB.getActivityLogs();
    logs.unshift(log);
    setLocalCache('activity_logs', logs);
  },

  // Daily summaries
  getDailySummaries: async (): Promise<any[]> => {
    return getLocalCache<any[]>('daily_summaries', []);
  },
  saveDailySummaries: async (summaries: any[]): Promise<void> => {
    setLocalCache('daily_summaries', summaries);
  },

  // Task analyses
  getTaskAnalyses: async (): Promise<any[]> => {
    return getLocalCache<any[]>('task_analyses', []);
  },
  saveTaskAnalyses: async (analyses: any[]): Promise<void> => {
    setLocalCache('task_analyses', analyses);
  },

  // Task Risk Scores
  getTaskRiskScores: async (): Promise<TaskRiskScore[]> => {
    return dataStore.getRiskScores();
  },
  saveTaskRiskScores: async (scores: TaskRiskScore[]): Promise<void> => {
    setLocalCache('task_risk', scores);
    for (const score of scores) {
      await dataStore.saveDocument<TaskRiskScore>('task_risk', score.id, score, initialRisks);
    }
  },

  // Duyen Config
  getDuyenConfig: async (): Promise<any> => {
    const defaultConf = {
      oaName: 'Vivian Decal',
      isActive: true,
      autoReply: true,
      welcomeText: 'Chào mừng quý khách đến với Vivian Decal. Em là Mỹ Duyên, trợ lý AI tư vấn in sấy UV tem nhãn!',
      personality: 'Thân thiện, chuyên nghiệp, hỗ trợ thực tế'
    };
    return getLocalCache<any>('duyen_config', defaultConf);
  },
  saveDuyenConfig: async (config: any): Promise<void> => {
    setLocalCache('duyen_config', config);
  },

  // Duyen Leads
  getDuyenLeads: async (): Promise<Lead[]> => {
    return dataStore.getLeads();
  },
  saveDuyenLead: async (lead: Lead): Promise<Lead> => {
    return dataStore.saveLead(lead);
  },

  // Notifications
  saveNotifications: async (notifs: Notification[]): Promise<void> => {
    setLocalCache('notifications', notifs);
  },

  // Chat History helper for AIAssistant.tsx
  saveChatHistory: async (userId: string, messages: any[]): Promise<void> => {
    setLocalCache(`chat_history_${userId}`, messages);
    if (messages.length > 0) {
      const last = messages[messages.length - 1];
      await dataStore.saveChatMessage(userId, last.sender === 'user' ? 'user' : 'assistant', last.text || last.content || '');
    }
  },

  // Extra Mock Logs needed for Dashboard
  getAiKpiLogs: async (): Promise<any[]> => {
    return getLocalCache<any[]>('ai_kpi_logs', []);
  },
  getEmployeeWorkloads: async (): Promise<EmployeeWorkload[]> => {
    return dataStore.getWorkloads();
  }
};
